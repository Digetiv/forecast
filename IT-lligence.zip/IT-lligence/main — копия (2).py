


from tkinter import *
from tkinter import ttk
import time

import python.fires_create as fires_predict
import python.dtp as dtp_predict
import python.ahov_create as ahov_predict
import python.natural as natural_predict
import python.other as other_predict
import python.other_avia as avia_predict
import python.other_bio as bio_predict
import python.other_neft as neft_predict
import python.zhkh_iz as zhkh_predict



class IT:
    def __init__(self):
        self.win = Tk()
        self.canvas = Canvas(self.win, width=1920, height=1080, bg='white')
        self.canvas.pack()
        self.tableim2 = []
        self.tableim = []
        self.time = time.time()
        self.end = 0

    def start(self):
        self.tableim2.append(self.canvas.create_image(0, 0, image=imgs['name'], anchor='nw'))

        # Создаем ряд из 6 иконок слева
        icon_row = []
        icon_spacing = 120  # Редактируемое расстояние между иконками
        j=0
        image1 = PhotoImage(file=f'images/i1.png')
        button1 = Button(self.win, image=image1, command=self.pb1)
        button1.image = image1
        icon_row.append(button1)
        self.tableim2.append(self.canvas.create_window(10, 20+j, window=button1, anchor='nw'))
        j+=120
        image2 = PhotoImage(file=f'images/i2.png')
        button2 = Button(self.win, image=image2, command=self.pb2)
        button2.image = image2
        icon_row.append(button2)
        self.tableim2.append(self.canvas.create_window(10, 20+j, window=button2, anchor='nw'))
        j+=120
        image3 = PhotoImage(file=f'images/i3.png')
        button3 = Button(self.win, image=image3, command=self.pb3)
        button3.image = image3
        icon_row.append(button3)
        self.tableim2.append(self.canvas.create_window(10, 20+j, window=button3, anchor='nw'))
        j+=120
        image4 = PhotoImage(file=f'images/i4.png')
        button4 = Button(self.win, image=image4, command=self.pb4)
        button4.image = image4
        icon_row.append(button4)
        self.tableim2.append(self.canvas.create_window(10, 20+j, window=button4, anchor='nw'))
        j+=120
        image5 = PhotoImage(file=f'images/i5.png')
        button5 = Button(self.win, image=image5, command=self.pb5)
        button5.image = image5
        icon_row.append(button5)
        self.tableim2.append(self.canvas.create_window(10, 20+j, window=button5, anchor='nw'))
        j+=120
        image6 = PhotoImage(file=f'images/i6.png')
        button6 = Button(self.win, image=image6, command=self.pb6)
        button6.image = image6
        icon_row.append(button6)
        self.tableim2.append(self.canvas.create_window(10, 20+j, window=button6, anchor='nw'))
        j+=120
        image7 = PhotoImage(file=f'images/i7.png')
        button7 = Button(self.win, image=image7, command=self.pb7)
        button7.image = image7
        icon_row.append(button7)
        self.tableim2.append(self.canvas.create_window(10, 20+j, window=button7, anchor='nw'))
        j+=120
        image8 = PhotoImage(file=f'images/i8.png')
        button8 = Button(self.win, image=image8, command=self.pb8)
        button8.image = image8
        icon_row.append(button8)
        self.tableim2.append(self.canvas.create_window(10, 20+j, window=button8, anchor='nw'))
        j+=120
        image9 = PhotoImage(file=f'images/i9.png')
        button9 = Button(self.win, image=image9, command=self.pb9)
        button9.image = image9
        icon_row.append(button9)
        self.tableim2.append(self.canvas.create_window(10, 20+j, window=button9, anchor='nw'))
        j+=120


        lst=['1','2','3']
        self.mvr=StringVar()
        self.lstbox=ttk.Combobox(textvariable=self.mvr)
        self.lstbox['values']=lst
        self.lstbox['state'] = 'readonly'

        btn2=Button(self.win, text='Выбрать регион', command=self.pb10)

        #self.tableim2.append(self.canvas.create_window(1900,400,window=self.lstbox,anchor='ne'))
        #self.tableim2.append(self.canvas.create_window(1900,360,window=btn2,anchor='ne'))

        
 #   def callback(self,*arg):
#        print(123)
#        print(str(combobox.current()+ str(var.get())))
    def clear(self):
        for i in self.tableim:
            self.canvas.delete(i)
        self.tableim = []

    def mainloop(self):
        while self.end == 0:
            self.move()
            self.draw()
            self.win.update()

            n = time.time() - self.time
            if n < 1/30:
                pass
            self.time = time.time()

    def draw(self):
        pass

    def move(self):
        pass

    def icon_click(self):
        pass

    def pb1(self):
        dt=(dtp_predict.main())
        self.inter2(dt)

    def pb2(self):
        dt=(ahov_predict.main())
        self.inter1(dt)

    def pb3(self):
        dt=(natural_predict.main())
        self.inter1(dt)

    def pb4(self):
        dt=(zhkh_predict.main())
        self.inter1(dt)

    def pb5(self):
        dt=(fires_predict.main())
        self.inter2(dt)

    def pb6(self):
        dt=(other_predict.main())
        self.inter1(dt)

    def pb7(self):
        dt=(avia_predict.main())
        self.inter1(dt)

    def pb8(self):
        dt=(neft_predict.main())
        self.inter1(dt)

    def pb9(self):
        dt=bio_predict.main()
        self.inter1(dt)
        

    def pb10(self):
        print(self.mvr.get())

    def inter1(self,dt):
        self.clear()
        y=550
        if '1' not in dt[0]:
            self.tableim.append(self.canvas.create_text(1900,450,text='В ближайшие дни аварийных ситуаций не спрогнозировано',anchor='ne'))
        else:
            st2=[]
            for i in range(len(dt[0])):
                if dt[0][i]=='1':
                    st2.append[i+1]
            
            self.tableim.append(self.canvas.create_text(1900,450,text='Аварийная ситуация ожидается через '+str(st2)+' дней',anchor='ne'))
        for st in dt[1]:
            self.tableim.append(self.canvas.create_text(1900,y,text=st,anchor='ne'))
            y+=25

        
        self.tableim.append(self.canvas.create_text(1900,y,text='Знаком "!" отмечены регионы,',anchor='ne'))
        y+=25
        self.tableim.append(self.canvas.create_text(1900,y,text='в которых аварийная ситуация наиболее ожидаема',anchor='ne'))
        y+=25
        for st in dt[2]:
            self.tableim.append(self.canvas.create_text(1900,y,text=st,anchor='ne'))
            y+=25
    def inter2(self,dt):
        self.clear()
        y=450
        self.tableim.append(self.canvas.create_text(1900,y,text='Ожидаемые уровни опасностей на ближайшие 10 дней:',anchor='ne'))
        y+=25
        for i in range(len(dt[0])):
            self.tableim.append(self.canvas.create_text(1900,y,text='Через '+str(i+1)+' дней: '+str(dt[0][i]),anchor='ne'))
            y+=25
        for st in dt[1]:
            self.tableim.append(self.canvas.create_text(1900,y,text=st,anchor='ne'))
            y+=25
        self.tableim.append(self.canvas.create_text(1900,y,text='Знаком "!" отмечены регионы,',anchor='ne'))
        y+=25
        self.tableim.append(self.canvas.create_text(1900,y,text='в которых аварийная ситуация наиболее ожидаема',anchor='ne'))
        y+=25
        for st in dt[2]:
            self.tableim.append(self.canvas.create_text(1900,y,text=st,anchor='ne'))
            y+=25

    


it = IT()
imgs = {
    'name': PhotoImage(file='images/13.png'),
}
it.start()
it.mainloop()
