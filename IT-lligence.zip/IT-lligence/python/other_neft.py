import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression     # Импортируем библиотеки
import plotly.graph_objs as go
from datetime import datetime, timedelta
from sklearn.metrics import accuracy_score, precision_score, recall_score
from scipy.stats import chi2_contingency  

def day_count(dt1,dt2):
    y1=int(dt1[:4])
    m1=int(dt1[5:7])
    d1=int(dt1[8:10])
    y2=int(dt2[:4])
    m2=int(dt2[5:7])
    d2=int(dt2[8:10])

    mdt1=day_in(y1,m1,d1)
    mdt2=day_in(y2,m2,d2)

    return mdt2-mdt1
def strd(d):
    st=str(d)
    if len(st)==1:
        st='0'+st
    return st

def day_in(y,m,d):
    day=0
    y-=2013
    vis=4
    while y>0:
        y-=1
        day+=365
        vis-=1
        if vis==0:
            vis=4
            day+=1
    m-=1
    ind=0
    month=[31,28,31,30,31,30,31,31,30,31,30,31]
    while m>0:
        day+=month[ind]
        if vis==1 and ind==1:
            day+=1
        m-=1
        ind+=1
    d-=1
    day+=d

    return day

def main():
    supa=dict()
    reader=pd.read_csv('db/Incidents.csv',delimiter=',',names=['district', 'type', 'time'])

    ln=len(reader)-1

    kewrd=['нефт','ефтян']
    arro=[]
    lday='2013-01-01'
    day=-1
    for i in range(1,ln):
        if reader['time'][i][:10]!=lday:
            day+=day_count(lday,reader['time'][i][:10])
            lday=reader['time'][i][:10]
        coll=0
        for wrd in kewrd:
            if wrd in reader['type'][i]:
                coll=1
        if coll==1:
            dst=reader['district'][i]
            while len(dst)>0 and dst[-1]==' ':
                dst=dst[:-1]
            su=supa.get(dst,0)
            su+=1
            supa[dst]=su+0
            arro.append([reader['time'][i][:10],day,reader['district'][i],1])

    supa2=[]
    for key in supa:
        supa2.append([supa[key],key])
    supa2.sort()
    supa3=[]
    ind=1
    while ind<len(supa2) and ind<5:
        supa3.append(supa2[-ind][1])
        ind+=1
    y=2013
    m=1
    d=1
    month=[31,28,31,30,31,30,31,31,30,31,30,31]
    dts=[]
    lday='2013-01-01'
    day=-1
    for i in arro:
        dts.append(i[0])
    while y<2023:
        dt=str(y)+'-'+strd(m)+'-'+strd(d)
        if dt!=lday:
            day+=day_count(lday,dt)
            lday=dt
        if dt not in dts:
            arro.append([dt,day,'МО',0])
    
        d+=1
        if d>month[m-1]:
            m+=1
            d=1
        if m>12:
            m=1
            d=1
            y+=1

    frame=pd.DataFrame(arro,
		 columns = ['data','last','district','bool'])
    frame.to_csv('new_db/other_neft.csv')

    reader=pd.read_csv('new_db/other_neft.csv',delimiter=',',names=['index','data', 'last', 'district','bool'])

    arro=[]

    ln=len(reader)-1
    for i in range(1,ln):
        arro.append([reader['data'][i],reader['last'][i],reader['district'][i],reader['bool'][i]])
    arro.sort()
    day=0
    for i in range(1,ln-1):
        day+=1
        arro[i][1]=day+0
        if arro[i][3]=='1':
            day=0

    frame=pd.DataFrame(arro,
		 columns = ['data','last','district','bool'])
    frame.to_csv('new_db/other_neft.csv')

    file='new_db/other_neft.csv'

    data = pd.read_csv(file)

# Подготовка данных
    data['data'] = pd.to_datetime(data['data'])

    data['Дни_с_текущей_даты'] = (data['data'].max() - data['data']).dt.days

    data['Целевая_переменная'] = data['bool'].shift(-10).fillna(0).astype(int)

# Выделение переменных
    X = data[['Дни_с_текущей_даты', 'last']]
    y = data['Целевая_переменная']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Модель ёмаё
    model = LogisticRegression()
    model.fit(X_train, y_train)

    current_date = data['data'].max()
    future_dates = [current_date + pd.DateOffset(days=i) for i in range(1, 11)]

    new_data = pd.DataFrame({'Дни_с_текущей_даты': list(range(1, 11)), 'last': [10] * 10})

# Прогноз + визуал
    predictions = model.predict(new_data)

#fig = go.Figure()
#fig.add_trace(go.Scatter(x=data['data'], y=data['bool'], mode='markers', name='Исходные данные'))

#n=1
#for date, prediction in zip(future_dates, predictions):
#    fig.add_trace(go.Scatter(x=[date], y=[prediction], mode='markers', name=f'Прогноз {n:.2f}'))
#    n+=1

#fig.update_layout(xaxis_title='Дата', yaxis_title='Происшествие (0 или 1)', title='Прогноз происшествия на 10 дней')
#fig.show()

    y_pred = model.predict(X_test)

# Метрики (проверка)
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)

    contingency_table = pd.crosstab(data['Дни_с_текущей_даты'], data['Целевая_переменная'])
    chi2, _, _, _ = chi2_contingency(contingency_table)
    n = contingency_table.sum().sum()
    kramer_corr = (chi2 / (n * min(contingency_table.shape[0] - 1, contingency_table.shape[1] - 1))) ** 0.5

    symmetry_corr = (kramer_corr * 2) - 1
    st=[]
    st.append(f'Accuracy: {accuracy:.2f}')
    st.append(f'Precision: {precision:.2f}')
    st.append(f'Recall: {recall:.2f}')
    st.append(f'Kramer: {kramer_corr:.2f}')
    st.append(f'Symmetry: {symmetry_corr:.2f}')


    return [list(y_pred[-10:]),st,supa3]


