import pandas as pd
import random
import math
import numpy as np
import plotly.graph_objs as go
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from scipy.stats import pearsonr, spearmanr

def strd(d):
    st=str(d)
    if len(st)==1:
        st='0'+st
    return st

def main():
    supa=dict()
    reader=pd.read_csv('db/Temperature statistics.csv',delimiter=',',names=['year', 'month', 'day','t'])
    ln=len(reader)-1
    temp=dict()
    for i in range(1,ln):
        y=reader['year'][i]
        if len(y)==4:
            m=reader['month'][i]
            if m=='январь': m='01'
            elif m=='февраль': m='02'
            elif m=='март': m='03'
            elif m=='апрель': m='04'
            elif m=='май': m='05'
            elif m=='июнь': m='06'
            elif m=='июль': m='07'
            elif m=='август': m='08'
            elif m=='сентябрь': m='09'
            elif m=='октябрь': m='10'
            elif m=='ноябрь': m='11'
            elif m=='декабрь': m='12'
            dt=y+'-'+m+'-'+strd(reader['day'][i])
            te=reader['t'][i]
            if te!='nan' and te!='' and te!=' ':
                temp[dt]=reader['t'][i]
                

    reader=pd.read_csv('db/Fires.csv',delimiter=',',names=['district', 'type', 'time','cou'])

    ln=len(reader)-1

    dct=dict()

    arro=[]
    cou=1
    last=''
    for i in range(1,ln):
        dst=reader['district'][i]
        while len(dst)>0 and dst[-1]==' ':
            dst=dst[:-1]
        su=supa.get(dst,0)
        su+=1
        supa[dst]=su+0
        dt=reader['time'][i][:10]
        if dt==last:
            cou+=1
        else:
            last=dt
            dst=reader['district'][i]
            while dst[-1]==' ':
                dst=dst[:-1]
            cou=cou//2+1
        
            arro.append([reader['time'][i][:10],dst,temp.get(dt,0),cou])
            cou=1
    supa2=[]
    for key in supa:
        supa2.append([supa[key],key])
    supa2.sort()
    supa3=[]
    ind=1
    while ind<len(supa2) and ind<5:
        supa3.append(supa2[-ind][1])
        ind+=1

    y=2013
    m=1
    d=1
    month=[31,28,31,30,31,30,31,31,30,31,30,31]
    dts=[]
    for i in arro:
        dts.append(i[0])
    while y<2023:
        dt=str(y)+'-'+strd(m)+'-'+strd(d)
        if dt not in dts:
            arro.append([dt,'МО',temp.get(dt,0),0])
        d+=1
        if d>month[m-1]:
            m+=1
            d=1
        if m>12:
            m=1
            d=1
            y+=1
    


    frame=pd.DataFrame(arro,
    		 columns = ['data','district','t','bool'])
    frame.to_csv('new_db/frs.csv')
    reader=pd.read_csv('new_db/frs.csv',delimiter=',',names=['index','data', 'district','t','bool'])

    arro=[]

    ln=len(reader)-1
    for i in range(1,ln):
        t=reader['t'][i]
        if t=='' or t==' ' or t=='nan' or math.isnan(float(t)):
            t='0'
        c=reader['bool'][i]
        arro.append([reader['data'][i],reader['district'][i],t,c])
    arro.sort()

    frame=pd.DataFrame(arro,
		 columns = ['data','district','t','bool'])
    frame.to_csv('new_db/frs.csv')

    
    data = pd.read_csv('new_db/frs.csv')

# Преобразование столбца 'date' в datetime
    data['data'] = pd.to_datetime(data['data'])

# Заполнение отсутствующих значений (NaN) в столбце 't' средними значениями
    data['t'].fillna(data['t'].mean(), inplace=True)

# Подготовка данных
    X = data[['t']]
    y = data['bool']

# Разделение данных на обучающий и тестовый наборы
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Обучение модели
    model = RandomForestRegressor()
    model.fit(X_train, y_train)

    st=[]

# Вывод коэффициентов модели (важности признаков для RandomForestRegressor)
    if isinstance(model, RandomForestRegressor):
        feature_importances = model.feature_importances_
        st.append("Feature Importances:")
        for i, importance in enumerate(feature_importances):
            st.append(f"Feature {X.columns[i]}: {importance}")
    elif isinstance(model, LinearRegression):
        coefficients = model.coef_
        st.append("Coefficients:")
        for i, coefficient in enumerate(coefficients):
            st.append(f"Coefficient for {X.columns[i]}: {coefficient}")

# Прогноз на следующие 10 дней
    forecast_dates = pd.date_range(start=data['data'].max(), periods=10)
    forecast_temperatures = [1, 3, 15, -8, 0, 0, 6, 4, 5, 2]  # Вам нужно заполнить температуры для будущих дней
    forecast_X = pd.DataFrame({'t': forecast_temperatures})
    forecast_X.index = forecast_dates
    forecast = model.predict(forecast_X)

# График с использованием Plotly


# Проверка корреляции
    correlation_pearson, _ = pearsonr(data['t'], data['bool'])
    correlation_spearman, _ = spearmanr(data['t'], data['bool'])
    st.append(f'Корреляция Пирсона: {correlation_pearson}')
    st.append(f'Корреляция Спирмена: {correlation_spearman}')

    return([list(y_test.tail(10)),st,supa3])
