import pandas as pd
import math
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression     # Импортируем библиотеки
import plotly.graph_objs as go
from datetime import datetime, timedelta
from sklearn.metrics import accuracy_score, precision_score, recall_score
from scipy.stats import chi2_contingency  

def day_count(dt1,dt2):
    y1=int(dt1[:4])
    m1=int(dt1[5:7])
    d1=int(dt1[8:10])
    y2=int(dt2[:4])
    m2=int(dt2[5:7])
    d2=int(dt2[8:10])

    mdt1=day_in(y1,m1,d1)
    mdt2=day_in(y2,m2,d2)

    return mdt2-mdt1
def strd(d):
    st=str(d)
    if len(st)==1:
        st='0'+st
    return st

def day_in(y,m,d):
    day=0
    y-=2013
    vis=4
    while y>0:
        y-=1
        day+=365
        vis-=1
        if vis==0:
            vis=4
            day+=1
    m-=1
    ind=0
    month=[31,28,31,30,31,30,31,31,30,31,30,31]
    while m>0:
        day+=month[ind]
        if vis==1 and ind==1:
            day+=1
        m-=1
        ind+=1
    d-=1
    day+=d

    return day

def main():
    supa=dict()

    reader=pd.read_csv('db/Temperature statistics.csv',delimiter=',',names=['year', 'month', 'day','t'])
    ln=len(reader)-1
    temp=dict()
    for i in range(1,ln):
        y=reader['year'][i]
        if len(y)==4:
            m=reader['month'][i]
            if m=='январь': m='01'
            elif m=='февраль': m='02'
            elif m=='март': m='03'
            elif m=='апрель': m='04'
            elif m=='май': m='05'
            elif m=='июнь': m='06'
            elif m=='июль': m='07'
            elif m=='август': m='08'
            elif m=='сентябрь': m='09'
            elif m=='октябрь': m='10'
            elif m=='ноябрь': m='11'
            elif m=='декабрь': m='12'
            dt=y+'-'+m+'-'+strd(reader['day'][i])
            te=reader['t'][i]
            if te!='nan' and te!='' and te!=' ':
                temp[dt]=reader['t'][i]

    reader=pd.read_csv('db/Natural incidents.csv',delimiter=',',names=['time','district','+', 'on', 'type','crit','har','fut'])

    ln=len(reader)-1

    arro=[]
    lday='2013-01-01'
    day=-1
    for i in range(1,ln):
        if(str(reader['time'][i])=='nan'): pass
        else:
           if reader['time'][i][:10]!=lday and math.isnan(float(reader['district'][i]))!=True:
                dst=reader['district'][i]
                while len(dst)>0 and dst[-1]==' ':
                    dst=dst[:-1]
                su=supa.get(dst,0)
                su+=1
                supa[dst]=su+0
                day+=day_count(lday,reader['time'][i][:10])
                lday=reader['time'][i][:10]
                dt=reader['time'][i][:10]
    
                arro.append([reader['time'][i][:10],day,temp.get(dt,0),1])
    supa2=[]
    for key in supa:
        supa2.append([supa[key],key])
    supa2.sort()
    supa3=[]
    ind=1
    while ind<len(supa2) and ind<5:
        supa3.append(supa2[-ind][1])
        ind+=1

    y=2013
    m=1
    d=1
    month=[31,28,31,30,31,30,31,31,30,31,30,31]
    dts=[]
    lday='2013-01-01'
    day=-1
    for i in arro:
        dts.append(i[0])
    while y<2023:
        dt=str(y)+'-'+strd(m)+'-'+strd(d)
        if dt!=lday:
            day+=day_count(lday,dt)
            lday=dt
        if dt not in dts:
            arro.append([dt,day,temp.get(dt,0),0])
    
        d+=1
        if d>month[m-1]:
            m+=1
            d=1
        if m>12:
            m=1
            d=1
            y+=1

    frame=pd.DataFrame(arro,
		 columns = ['data','last','t','bool'])
    frame.to_csv('new_db/natural-data.csv')
    reader=pd.read_csv('new_db/natural-data.csv',delimiter=',',names=['index','data', 'last','t','bool'])

    arro=[]

    ln=len(reader)-1
    for i in range(1,ln):
        t=reader['t'][i]
        if t=='' or t==' ' or t=='nan' or math.isnan(float(t)):
            t='0'
        c=reader['bool'][i]
        arro.append([reader['data'][i],reader['last'][i],t,c])
    arro.sort()
    day=0
    for i in range(1,ln-1):
        day+=1
        arro[i][1]=day+0
        if arro[i][3]=='1':
            day=0
    
    frame=pd.DataFrame(arro,
		 columns = ['data','last','t','bool'])
    frame.to_csv('new_db/natural-data.csv')

    data = pd.read_csv('new_db/natural-data.csv')

# Подготовка данных
    data['data'] = pd.to_datetime(data['data'])

    data['Дни_с_текущей_даты'] = (data['data'].max() - data['data']).dt.days

    data['Целевая_переменная'] = data['bool'].shift(-10).fillna(0).astype(int)

# Выделение переменных
    X = data[['Дни_с_текущей_даты', 'last']]
    y = data['Целевая_переменная']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Модель ёмаё
    model = LogisticRegression()
    model.fit(X_train, y_train)

    current_date = data['data'].max()
    future_dates = [current_date + pd.DateOffset(days=i) for i in range(1, 11)]

    new_data = pd.DataFrame({'Дни_с_текущей_даты': list(range(1, 11)), 'last': [10] * 10})

# Прогноз + визуал
    predictions = model.predict(new_data)


    y_pred = model.predict(X_test)

# Метрики (проверка)
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)

    contingency_table = pd.crosstab(data['Дни_с_текущей_даты'], data['Целевая_переменная'])
    chi2, _, _, _ = chi2_contingency(contingency_table)
    n = contingency_table.sum().sum()
    kramer_corr = (chi2 / (n * min(contingency_table.shape[0] - 1, contingency_table.shape[1] - 1))) ** 0.5

    symmetry_corr = (kramer_corr * 2) - 1
    st=[]
    
    st.append(f'Accuracy: {accuracy:.2f}')
    st.append(f'Precision: {precision:.2f}')
    st.append(f'Recall: {recall:.2f}')
    st.append(f'Kramer: {kramer_corr:.2f}')
    st.append(f'Symmetry: {symmetry_corr:.2f}')

    return([list(y_test.tail(10)),st,supa3])

