import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression     # Импортируем библиотеки
import plotly.graph_objs as go
from datetime import datetime, timedelta
from sklearn.metrics import accuracy_score, precision_score, recall_score
from scipy.stats import chi2_contingency  
import random
def day_count(dt1,dt2):
    y1=int(dt1[:4])
    m1=int(dt1[5:7])
    d1=int(dt1[8:10])
    y2=int(dt2[:4])
    m2=int(dt2[5:7])
    d2=int(dt2[8:10])

    mdt1=day_in(y1,m1,d1)
    mdt2=day_in(y2,m2,d2)

    return mdt2-mdt1
def strd(d):
    st=str(d)
    if len(st)==1:
        st='0'+st
    return st

def day_in(y,m,d):
    day=0
    y-=2013
    vis=4
    while y>0:
        y-=1
        day+=365
        vis-=1
        if vis==0:
            vis=4
            day+=1
    m-=1
    ind=0
    month=[31,28,31,30,31,30,31,31,30,31,30,31]
    while m>0:
        day+=month[ind]
        if vis==1 and ind==1:
            day+=1
        m-=1
        ind+=1
    d-=1
    day+=d

    return day
def flo(f):
    f=str(f)
    if f=='' or f==' ' or f=='-' or f=='nan':
        return 0
    else:
        return float(f)

def main():
    supa=dict()

    reader=pd.read_csv('db/Network deterioration.csv',delimiter=',',names=['district', 'k1', 'k2', 'k3', 'k4', 'k5', 'k6', 'k7', 'k8', 'k9', 'k10', 'k11', 'k12', 'k13'])

    ln=len(reader)
    arr_h=dict()
    dsts=[]
    for i in range(1,ln):
        nm=reader['district'][i].replace('муниципальный округ','МО')
        nm=nm.replace('городской округ','ГО')
        nm=nm.replace('муниципальное образование','ГО')
        nm=nm.replace('"','')
        while nm[-1]==' ':
            nm=nm[:-1]
        dsts.append(nm)
        arr_h[nm]=[flo(reader['k1'][i]),flo(reader['k2'][i]),flo(reader['k3'][i]),flo(reader['k4'][i]),flo(reader['k5'][i]),flo(reader['k6'][i]),flo(reader['k8'][i]),flo(reader['k10'][i]),flo(reader['k11'][i]),flo(reader['k12'][i]),flo(reader['k13'][i])]


    reader=pd.read_csv('db/Incidents.csv',delimiter=',',names=['district', 'type', 'time'])
    ln=len(reader)-1
    arro=[]
    lday='2013-01-01'
    day=-1
    for i in range(1,ln):
        if reader['time'][i][:10]!=lday:
            day+=day_count(lday,reader['time'][i][:10])
            lday=reader['time'][i][:10]
        
    
    
        ind=-1
        if 'тепло' in reader['type'][i]:
            ind=1
        if 'ХВС' in reader['type'][i]:
            ind=2
        if 'ГВС' in reader['type'][i]:
            ind=3
        if 'электро' in reader['type'][i]:
            ind=4
        if 'азо' in reader['type'][i]:
            ind=5
        if 'одозаб' in reader['type'][i]:
            ind=7
        if 'очист' in reader['type'][i]:
            ind=8
        if 'анализа' in reader['type'][i]:
            ind=9
        if 'отельные' in reader['type'][i]:
            ind=10
        if ind !=-1:
            dst=reader['district'][i]
            while dst[-1]==' ':
                dst=dst[:-1]
            dst=reader['district'][i]
            while len(dst)>0 and dst[-1]==' ':
                dst=dst[:-1]
            su=supa.get(dst,0)
            su+=1
            supa[dst]=su+0
            arro.append([reader['time'][i][:10],day,dst,arr_h.get(dst,[0,0,0,0,0,0,0,0,0,0,0])[ind],1])
    supa2=[]
    for key in supa:
        supa2.append([supa[key],key])
    supa2.sort()
    supa3=[]
    ind=1
    while ind<len(supa2) and ind<5:
        supa3.append(supa2[-ind][1])
        ind+=1
    y=2013
    m=1
    d=1
    month=[31,28,31,30,31,30,31,31,30,31,30,31]
    dts=[]
    lday='2013-01-01'
    day=-1
    for i in arro:
        dts.append(i[0])
    while y<2023:
        dt=str(y)+'-'+strd(m)+'-'+strd(d)
        if dt!=lday:
            day+=day_count(lday,dt)
            lday=dt
        if dt not in dts:
            dst=random.choice(dsts)
            iz=arr_h.get(dst,[0,0,0,0,0,0,0,0,0,0,0])
            iz=random.choice(iz)
            arro.append([dt,day,dst,iz,0])
    
        d+=1
        if d>month[m-1]:
            m+=1
            d=1
        if m>12:
            m=1
            d=1
            y+=1


    


    frame=pd.DataFrame(arro,
		 columns = ['data','last','district','iznos','bool'])
    frame.to_csv('new_db/zhkh.csv')

    reader=pd.read_csv('new_db/zhkh.csv',delimiter=',',names=['index','data', 'last', 'district','iznos','bool'])

    arro=[]

    ln=len(reader)-1
    for i in range(1,ln):
        arro.append([reader['data'][i],reader['last'][i],reader['district'][i],reader['iznos'][i],reader['bool'][i]])
    arro.sort()
    day=0
    for i in range(1,ln-1):
        day+=1
        arro[i][1]=day+0
        if arro[i][3]=='1':
            day=0

    frame=pd.DataFrame(arro,
		 columns = ['data','last','district','iznos','bool'])
    frame.to_csv('new_db/zhkh.csv')


    file='new_db/zhkh.csv'

    data = pd.read_csv(file)

# Подготовка данных
    data['data'] = pd.to_datetime(data['data'])

    data['Дни_с_текущей_даты'] = (data['data'].max() - data['data']).dt.days

    data['Целевая_переменная'] = data['bool'].shift(-10).fillna(0).astype(int)

# Выделение переменных
    X = data[['Дни_с_текущей_даты', 'last', 'iznos']]
    y = data['Целевая_переменная']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Модель ёмаё
    model = LogisticRegression()
    model.fit(X_train, y_train)

    current_date = data['data'].max()
    future_dates = [current_date + pd.DateOffset(days=i) for i in range(1, 11)]

    new_data = pd.DataFrame({'Дни_с_текущей_даты': list(range(1, 11)), 'last': [10] * 10, 'iznos': [0] * 10})

# Прогноз + визуал
    predictions = model.predict(new_data)

#fig = go.Figure()
#fig.add_trace(go.Scatter(x=data['data'], y=data['bool'], mode='markers', name='Исходные данные'))

#n=1
#for date, prediction in zip(future_dates, predictions):
#    fig.add_trace(go.Scatter(x=[date], y=[prediction], mode='markers', name=f'Прогноз {n:.2f}'))
#    n+=1

#fig.update_layout(xaxis_title='Дата', yaxis_title='Происшествие (0 или 1)', title='Прогноз происшествия на 10 дней')
#fig.show()

    y_pred = model.predict(X_test)

# Метрики (проверка)
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)

    contingency_table = pd.crosstab(data['Дни_с_текущей_даты'], data['Целевая_переменная'])
    chi2, _, _, _ = chi2_contingency(contingency_table)
    n = contingency_table.sum().sum()
    kramer_corr = (chi2 / (n * min(contingency_table.shape[0] - 1, contingency_table.shape[1] - 1))) ** 0.5

    symmetry_corr = (kramer_corr * 2) - 1
    st=[]
    st.append(f'Accuracy: {accuracy:.2f}')
    st.append(f'Precision: {precision:.2f}')
    st.append(f'Recall: {recall:.2f}')
    st.append(f'Kramer: {kramer_corr:.2f}')
    st.append(f'Symmetry: {symmetry_corr:.2f}')


    return [list(y_pred[-10:]),st,supa3]
