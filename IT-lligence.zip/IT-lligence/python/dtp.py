import pandas as pd
from prophet import Prophet
import plotly.graph_objs as go
import math

def strd(d):
    st=str(d)
    if len(st)==1:
        st='0'+st
    return st

def main():
    supa=dict()
    reader=pd.read_csv('db/DTP.csv',delimiter=',',names=['district', 'type', 'time','c'])

    ln=len(reader)-1

    arro=[]
    cou=1
    last='123'
    for i in range(1,ln):
        
        if '-' not in reader['time'][i][:4] and '.' not in reader['time'][i][:4]:
            dst=reader['district'][i]
            while len(dst)>0 and dst[-1]==' ':
                dst=dst[:-1]
            su=supa.get(dst,0)
            su+=1
            supa[dst]=su+0
            if reader['time'][i][:10]==last:
                cou+=1
            else:
                last=reader['time'][i][:10]
                dst=reader['district'][i]
                while len(dst)>0 and dst[-1]==' ':
                    dst=dst[:-1]
                arro.append([reader['time'][i][:10],dst,cou//3+1])
                cou=1
    supa2=[]
    for key in supa:
        supa2.append([supa[key],key])
    supa2.sort()
    supa3=[]
    ind=1
    while ind<len(supa2) and ind<5:
        supa3.append(supa2[-ind][1])
        ind+=1

    y=2013
    m=1
    d=1
    month=[31,28,31,30,31,30,31,31,30,31,30,31]
    dts=[]
    for i in arro:
        dts.append(i[0])
    while y<2023:
        dt=str(y)+'-'+strd(m)+'-'+strd(d)
        if dt not in dts:
            arro.append([dt,'МО',0])
    
        d+=1
        if d>month[m-1]:
            m+=1
            d=1
        if m>12:
            m=1
            d=1
            y+=1

    frame=pd.DataFrame(arro,
		 columns = ['data','district','bool'])
    frame.to_csv('new_db/dtp-data.csv')

    reader=pd.read_csv('new_db/dtp-data.csv',delimiter=',',names=['index','data', 'district','bool'])

    arro=[]

    ln=len(reader)-1
    for i in range(1,ln):
        c=reader['bool'][i]
        arro.append([reader['data'][i],reader['district'][i],c])
    arro.sort()
    dg=[]
    for i in range(1,ln-1):
        if arro[i][0]==arro[i-1][0]:
            dg.append(i-1)
            arro[i][2]=int(arro[i-1][2])+int(arro[i][2])

    for i in range(len(dg)):
        arro.pop(dg[len(dg)-1-i])

    frame=pd.DataFrame(arro,
		 columns = ['data','district','bool'])
    frame.to_csv('new_db/dtp-data.csv')

    data = pd.read_csv('new_db/dtp-data.csv')

# Преобразование столбца 'date' в datetime
    data['ds'] = pd.to_datetime(data['data'])

# Подготовка данных для модели Prophet
    data = data.rename(columns={'ds': 'ds', 'bool': 'y'})

# Создание и обучение модели
    model = Prophet(daily_seasonality=True)
    model.fit(data)

# Создание фрейма данных для прогноза на 10 дней вперед
    future = model.make_future_dataframe(periods=10)

# Получение прогноза
    forecast = model.predict(future)

# График с использованием Plotly


# Вывод прогноза на 10 дней вперед
    forecast_10_days = forecast[ 'yhat'][-10:]
    return([list(forecast_10_days.tail(10)),[],supa3])

